---
layout: default
title: Home
permalink: /home/
---

<div class="home-page">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <h1>Welcome to Our Studio</h1>
        <p class="lead">It's nice to meet you</p>
      </div>
    </div>
  </div>

  {% include services.html %}
  {% include portfolio_grid.html %}
</div>
