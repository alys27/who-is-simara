Personal Portfolio Website (Jekyll)

A personal portfolio website prepared for the SITE 1101 – Principles of Information Systems course.

✨ This website was built using Jekyll (for a 10% bonus)

📋 Description

This website was developed using the Jekyll static site generator, along with HTML, CSS, and JavaScript. The site features a responsive design, ensuring proper display and usability on mobile, tablet, and desktop devices.

🚀 Features

✅ Home Page (profile photo and introduction text)

✅ About Page (background, qualifications, activities)

✅ Projects Page (Project 1 and other projects)

✅ Contact Page

✅ Navigation bar and Footer

✅ GitHub and Codecademy icon links

✅ Responsive design (mobile and tablet support)

✅ Clean and modular code structure

✅ Jekyll static site generator (10% bonus)

📁 Structure
alys27.github.io/
├── _config.yml          # Jekyll configuration
├── _layouts/
│   └── default.html     # Main layout
├── _includes/
│   ├── header.html      # Navigation bar
│   └── footer.html      # Footer
├── index.html           # Home page
├── about.html           # About page
├── projects.html        # Projects page
├── contact.html         # Contact page
├── css/
│   └── style.css        # Main CSS file
├── js/
│   └── main.js          # JavaScript file
├── images/              # Images folder
│   ├── profile.jpg      # Profile image
│   ├── project1.jpg     # Project 1 image
│   ├── project2.jpg     # Project 2 image
│   └── project3.jpg     # Project 3 image
├── Gemfile              # Ruby dependencies
└── README.md            # This file

🔧 Installation
For Local Development

Install Ruby and Bundler:

Windows: RubyInstaller

macOS: brew install ruby

Linux: sudo apt-get install ruby-full

Clone the repository:

git clone https://github.com/alys27/alys27.github.io.git
cd alys27.github.io


Install dependencies:

bundle install


Start the Jekyll server:

bundle exec jekyll serve


Open in your browser: http://localhost:4000

Hosting on GitHub Pages

GitHub Pages automatically builds Jekyll sites. Simply:

Push the repository to GitHub

Go to Settings > Pages and select Jekyll

Your website will be live!

📝 Configuration

To use the website, update the information in the _config.yml file:

author: "Simara Aliyeva"
email: "your.email@example.com"
github_username: "alys27"
codecademy_username: "alyss27"
repository: "site1101-portfolio"

🌐 GitHub Pages

To host the website on GitHub Pages:

Go to your GitHub repository

Navigate to Settings > Pages

Under Source, select Deploy from a branch

Choose branch: main and folder: / (root)

Click Save

GitHub Pages will automatically build the site using Jekyll

After a few minutes, your website will be available at
https://alys27.github.io

📄 License

This project was created for educational purposes.

👤 Author

Simara Aliyeva – SITE 1101 Student

🔗 Links

GitHub Profile

Codecademy Profile

Website Repository

🎯 Advantages of Jekyll

✅ Modular code structure (layouts and includes)

✅ Automatic site generation

✅ Native GitHub Pages support

✅ Markdown support

✅ Liquid template engine

✅ Plugin system