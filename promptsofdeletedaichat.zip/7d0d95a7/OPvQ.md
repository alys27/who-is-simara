---
layout: single
title: "Hi, I'm Simara Aliyeva"
permalink: /
author_profile: true
header:
  image: /assets/images/header.jpg
---

## Web Developer & Designer

Creating beautiful and functional web experiences with HTML, CSS, and JavaScript.

### Featured Projects

[View All Projects](projects){: .btn .btn--primary}
