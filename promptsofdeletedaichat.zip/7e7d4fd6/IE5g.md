# Simara Aliyeva's Personal Portfolio

A professional, responsive personal portfolio website showcasing my skills, projects, and background. Built with HTML5, CSS3, and JavaScript for SITE 1101: Principles of Information Systems.

## 📁 Project Structure

```
project3/
├── index.html           # Home page
├── about.html          # About page
├── projects.html       # Projects page
├── css/
│   └── style.css       # Main stylesheet with responsive design
├── js/
│   └── script.js       # JavaScript for interactivity
├── images/             # Image assets directory
│   ├── profile.jpg     # Profile photo (add your photo here)
│   ├── project1-placeholder.jpg
│   ├── project2-placeholder.jpg
│   └── project3-placeholder.jpg
└── README.md          # This file
```

## 🎨 Features

- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile devices
- **Navigation Bar**: Sticky navigation with mobile hamburger menu
- **Home Page**: Hero section with profile photo and introduction
- **About Page**: Background, skills, qualifications, and journey timeline
- **Projects Page**: Detailed project cards with descriptions and links
- **Footer**: Quick links and social media connections
- **Clean Code**: Modular and well-organized HTML, CSS, and JavaScript
- **Animations**: Smooth transitions and scroll effects
- **Accessibility**: Semantic HTML and proper meta tags

## 🚀 Getting Started

### Prerequisites

- A modern web browser (Chrome, Firefox, Safari, Edge)
- A text editor (VS Code, Cursor, etc.)
- Git (for version control)

### Setup Instructions

1. **Clone or download the repository**
   ```bash
   git clone https://github.com/YOUR_GITHUB_USERNAME/site1101.git
   cd site1101
   ```

2. **View the website locally**
   - Option A: Use LiveServer extension in VS Code
     - Open the project folder in VS Code
     - Right-click on `index.html` and select "Open with Live Server"
   
   - Option B: Open directly in browser
     - Double-click `index.html` to open in your default browser

3. **Customize the portfolio**
   - Update profile information in HTML files
   - Replace placeholder images with your own photos
   - Update social media links (GitHub, Codecademy, LinkedIn)
   - Add your projects with descriptions and images
   - Modify colors and styles in `css/style.css` as needed

## 📝 Customization Guide

### Update Personal Information

In `index.html`, `about.html`, and `projects.html`:
- Replace `Simara Aliyeva` with your name
- Update email and location
- Change social media profile URLs

### Add Your Projects

In `projects.html`:
1. Update Project 1 with your portfolio project details
2. Add Project 2 (Hour of Code) if applicable
3. Add additional projects as needed
4. Update project images

### Update Images

Place your images in the `images/` folder:
- `profile.jpg` - Your profile photo (recommended: 200x200px)
- `project1-placeholder.jpg` - Screenshot of Project 1
- `project2-placeholder.jpg` - Screenshot of Project 2
- Add more as needed

### Modify Colors

Edit CSS variables in `css/style.css` (line 6-13):
```css
:root {
    --primary-color: #2563eb;
    --secondary-color: #1e40af;
    --accent-color: #0f766e;
    /* ... other variables ... */
}
```

## 🔧 Version Control with Git

### Make Your First Commit

```bash
# Check status
git status

# Add all files
git add .

# Commit with message
git commit -m "Initial portfolio setup"

# Push to GitHub
git push origin main
```

### Regular Commits

Make commits as you update the portfolio:

```bash
# After making changes
git add .
git commit -m "Add project 1 details"
git push origin main
```

## 🌐 Deploy to GitHub Pages

1. **Create a GitHub repository**
   - Go to github.com and create a new public repository
   - Name it `site1101` or `[username].github.io` for main portfolio

2. **Push your code**
   ```bash
   git remote add origin https://github.com/YOUR_USERNAME/site1101.git
   git push -u origin main
   ```

3. **Enable GitHub Pages**
   - Go to Settings → Pages
   - Select main branch as source
   - Save

4. **Access your website**
   - If repo is `site1101`: https://YOUR_USERNAME.github.io/site1101
   - If repo is `YOUR_USERNAME.github.io`: https://YOUR_USERNAME.github.io

## 📱 Responsive Breakpoints

- **Desktop**: 1200px and above
- **Tablet**: 768px - 1199px
- **Mobile**: Below 768px
- **Small Mobile**: 480px and below

## 🛠️ Technologies Used

- **HTML5**: Semantic markup and structure
- **CSS3**: Flexbox, Grid, and responsive design
- **JavaScript**: DOM manipulation and interactivity
- **Font Awesome**: Icons library
- **Git**: Version control
- **GitHub Pages**: Hosting

## 📋 Checklist for Submission

- [ ] Website has Home, About, and Projects pages
- [ ] Navigation bar and footer are present
- [ ] GitHub and Codecademy profile links included
- [ ] Link to GitHub repository added
- [ ] Profile photo uploaded
- [ ] Project 1 details and images added
- [ ] Responsive design tested on mobile
- [ ] Git commits made with meaningful messages
- [ ] Code is clean and well-organized
- [ ] Website deployed on GitHub Pages
- [ ] AI chat exported as markdown file

## 📚 Resources

- [MDN Web Docs](https://developer.mozilla.org)
- [CSS-Tricks](https://css-tricks.com)
- [GitHub Pages Guide](https://pages.github.com)
- [Font Awesome Icons](https://fontawesome.com)
- [Can I Use](https://caniuse.com) - Browser compatibility

## 📧 Contact

For questions or suggestions about this portfolio, reach out through:
- GitHub: https://github.com/YOUR_GITHUB_USERNAME
- Codecademy: https://www.codecademy.com/profiles/YOUR_CODECADEMY_USERNAME
- Email: your.email@example.com

## 📄 License

This project is open source and available for educational purposes.

---

**Happy coding!** 🚀

Last updated: December 2025
