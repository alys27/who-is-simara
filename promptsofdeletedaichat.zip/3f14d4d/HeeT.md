# Quick Reference Guide

## 🎯 Getting Started in 5 Steps

### Step 1: Open the Website Locally
- Open VS Code or Cursor
- Open the `project3` folder
- Right-click `index.html` → "Open with Live Server"
- Website opens in your browser

### Step 2: Customize Your Information
Edit these files and replace placeholders:

**In all HTML files:**
- Replace `Simara Aliyeva` with your name
- Replace email address
- Replace location/city
- Replace social media usernames

**Required replacements:**
- `YOUR_GITHUB_USERNAME` → your actual GitHub username
- `YOUR_CODECADEMY_USERNAME` → your Codecademy profile
- Contact information → your actual contact info

### Step 3: Add Your Images
Create folder `images` with these files:
- `profile.jpg` (200x200px) - Your profile photo
- `project1-placeholder.jpg` (400x300px) - Project 1 screenshot
- `project2-placeholder.jpg` (optional) - Project 2 screenshot

### Step 4: Set Up Git & GitHub
```bash
# Initialize Git
git init
git add .
git commit -m "Initial portfolio setup"

# Create GitHub repo at github.com
# Name it: site1101
# Make it PUBLIC

# Push to GitHub
git remote add origin https://github.com/YOUR_USERNAME/site1101.git
git branch -M main
git push -u origin main
```

### Step 5: Deploy & Submit
1. Go to GitHub Settings → Pages
2. Select "main" branch → Save
3. Wait 1-2 minutes
4. Website at: `https://YOUR_USERNAME.github.io/site1101`
5. Submit three links:
   - Website URL
   - Repository URL
   - AI Chat Export (markdown file)

---

## 📝 File Descriptions

| File | Purpose | Edit? |
|------|---------|-------|
| `index.html` | Home page | ✏️ Yes |
| `about.html` | About page | ✏️ Yes |
| `projects.html` | Projects page | ✏️ Yes |
| `css/style.css` | Styling | ✏️ Optional |
| `js/script.js` | Interactivity | ❌ No |
| `README.md` | Documentation | ✏️ Optional |
| `SETUP_GUIDE.md` | Setup instructions | ❌ No |
| `PROJECT_SUMMARY.md` | Project overview | ❌ No |

---

## 🔍 What to Replace in HTML Files

### In `index.html`:
```html
<!-- Change this: -->
<img src="images/profile.jpg" alt="Simara Aliyeva">

<!-- Change this: -->
<h1>Hi, I'm Simara Aliyeva</h1>

<!-- Change this: -->
<a href="https://github.com/YOUR_GITHUB_USERNAME">

<!-- Change this: -->
<a href="https://www.codecademy.com/profiles/YOUR_CODECADEMY_USERNAME">
```

### In `about.html`:
```html
<!-- Update your information: -->
<p>I'm Simara Aliyeva, an Information Systems student...</p>

<!-- Update contact details: -->
<p><strong>Email:</strong> your.email@example.com</p>
<p><strong>Location:</strong> Your City</p>

<!-- Update social links: -->
<a href="https://github.com/YOUR_GITHUB_USERNAME">
```

### In `projects.html`:
```html
<!-- Update project details: -->
<h3>Project 1: Your Project Title</h3>
<p>Your project description...</p>

<!-- Update project image: -->
<img src="images/project1-placeholder.jpg" alt="Your Project">

<!-- Update links: -->
<a href="https://github.com/YOUR_GITHUB_USERNAME/project-repo">
```

---

## 🎨 Customize Colors (Optional)

Edit `css/style.css` (lines 6-13):

```css
:root {
    --primary-color: #2563eb;      /* Main blue */
    --secondary-color: #1e40af;    /* Darker blue */
    --accent-color: #0f766e;       /* Teal */
    --text-dark: #1f2937;          /* Dark text */
    --text-light: #6b7280;         /* Light text */
}
```

Popular color combinations:
- **Professional:** Blue + Navy + Gray
- **Modern:** Purple + Pink + Black
- **Warm:** Orange + Red + Brown
- **Cool:** Cyan + Blue + Navy

---

## 🚀 Common Git Commands

```bash
# Check what changed
git status

# Add all changes
git add .

# Commit with message
git commit -m "Your message here"

# Push to GitHub
git push origin main

# View commit history
git log --oneline

# Create a new branch
git checkout -b feature-name

# Switch to main branch
git checkout main
```

---

## 📱 Test Responsiveness

### In Browser DevTools (F12):
1. Click Device Toolbar icon
2. Select device:
   - iPhone 12: 390px
   - iPad: 768px
   - Desktop: 1920px

### Checklist:
- [ ] Mobile menu appears on small screens
- [ ] Text is readable (not too small)
- [ ] Images scale properly
- [ ] No horizontal scrolling
- [ ] Buttons are clickable on mobile
- [ ] Navigation works on all sizes

---

## ❌ Common Mistakes to Avoid

1. **Forgetting to replace placeholders**
   - Check for "Simara", "YOUR_", "example.com"
   - Test all links work

2. **Making repository private**
   - GitHub Pages only works with public repos
   - Check Settings → Visibility is "Public"

3. **Wrong folder structure**
   - Images must be in `images/` folder
   - CSS must be in `css/` folder
   - JavaScript must be in `js/` folder

4. **Broken image paths**
   - Use relative paths: `images/photo.jpg`
   - Don't use absolute paths: `C:/Users/.../photo.jpg`
   - Check file names (case-sensitive on GitHub)

5. **Forgetting to push to GitHub**
   - Always `git push origin main` after commits
   - Check GitHub repo to verify changes appear

6. **Not making multiple commits**
   - Make commits as you update content
   - Shows development progress
   - Required for grading

7. **Forgetting AI chat export**
   - Export from Cursor/VSCode
   - Save as markdown file
   - Add to repository and push

---

## ✅ Pre-Submission Checklist

### Content
- [ ] All name placeholders replaced
- [ ] Email address updated
- [ ] Profile photo added
- [ ] Project details filled in
- [ ] Social media links updated
- [ ] No broken links
- [ ] No placeholder text remaining

### Technical
- [ ] Website works locally
- [ ] Responsive design tested
- [ ] Git repository initialized
- [ ] GitHub repo created and public
- [ ] Code pushed to GitHub
- [ ] GitHub Pages deployed
- [ ] Website accessible at correct URL

### Documentation
- [ ] AI chat exported as markdown
- [ ] AI chat file added to repo
- [ ] README.md is present
- [ ] Commits visible in history

### Submission
- [ ] Website URL ready
- [ ] Repository URL ready
- [ ] AI chat markdown file ready
- [ ] All URLs tested and working

---

## 📞 Quick Help

**"How do I view my website locally?"**
→ Right-click `index.html` → Open with Live Server

**"How do I add my photo?"**
→ Save as `images/profile.jpg`, update src in HTML

**"How do I update my name everywhere?"**
→ Use Find & Replace (Ctrl+H): find "Simara Aliyeva", replace with your name

**"How do I deploy to GitHub Pages?"**
→ Settings → Pages → Select "main" branch → Save

**"Where is my website URL?"**
→ `https://YOUR_GITHUB_USERNAME.github.io/site1101`

**"How do I make commits?"**
→ `git add .` → `git commit -m "message"` → `git push origin main`

**"Where do I export AI chat?"**
→ Cursor/VSCode: Click three dots in chat → Export as Markdown

---

## 🎓 Learning Resources

- **HTML Guide:** MDN Web Docs (mdn.org)
- **CSS Reference:** CSS-Tricks (css-tricks.com)
- **Git Tutorial:** Git Book (git-scm.com/book)
- **Icons:** Font Awesome (fontawesome.com)
- **Colors:** Coolors (coolors.co)

---

## 🎉 You're Ready!

Your portfolio is set up and ready to go. Just:
1. Add your personal information
2. Add your photos
3. Make Git commits
4. Deploy to GitHub Pages
5. Submit your links

**Good luck with your project!** 🚀
