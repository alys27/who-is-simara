document.addEventListener('DOMContentLoaded',()=>{
  const toggle = document.getElementById('nav-toggle');
  const nav = document.getElementById('main-nav');
  if(toggle && nav){
    toggle.addEventListener('click',()=>nav.classList.toggle('open'))
  }

  const year = document.getElementById('year');
  if(year) year.textContent = new Date().getFullYear();

  const form = document.getElementById('contact-form');
  if(form){
    form.addEventListener('submit',e=>{
      e.preventDefault();
      alert('Thanks — your message has been noted (this form is static).');
      form.reset();
    })
  }
});
