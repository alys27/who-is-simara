---
layout: default
title: Who Is Simara
---

<section class="hero">
  <div class="container hero-inner">
    <div class="avatar">SA</div>
    <div class="hero-copy">
      <h1>Hi, I’m Simara — I build thoughtful web experiences.</h1>
      <p class="lead">Frontend developer passionate about accessibility, performance, and clean design.</p>
      <div class="hero-actions">
        <a class="btn primary" href="#projects">View Projects</a>
        <a class="btn" href="#contact">Get In Touch</a>
      </div>
    </div>
  </div>
</section>

<section id="about" class="section container about">
  <h2>About</h2>
  <p>I’m a frontend developer specializing in building accessible, responsive interfaces. I enjoy turning complex problems into simple, beautiful user experiences.</p>
</section>

<section id="projects" class="section container projects">
  <h2>Selected Projects</h2>
  <div class="grid">
    <article class="card">
      <h3>Project One</h3>
      <p>Short description of the project and the technologies used.</p>
      <a class="card-link" href="#">View case study →</a>
    </article>
    <article class="card">
      <h3>Project Two</h3>
      <p>Short description of the project and the technologies used.</p>
      <a class="card-link" href="#">View case study →</a>
    </article>
    <article class="card">
      <h3>Project Three</h3>
      <p>Short description of the project and the technologies used.</p>
      <a class="card-link" href="#">View case study →</a>
    </article>
  </div>
</section>

<section id="contact" class="section container contact">
  <h2>Contact</h2>
  <p>Want to work together? Send a message or email me directly.</p>
  <a class="btn primary" href="mailto:your-email@example.com">Email Me</a>
</section>
