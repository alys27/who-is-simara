# Portfolio — Local Preview

This is a simple static portfolio site with pages: Home, About, Projects, Contact.

Open `index.html` directly in your browser, or run a local static server for best results.

Quick local server (Python 3):

```powershell
cd "c:\Users\Simara Aliyeva\OneDrive\Desktop\infosyst\whoissimara"
python -m http.server 8000
# then open http://localhost:8000
```

If you use VS Code, the Live Server extension also works well.

Next steps you might want:
- Replace placeholder text and project descriptions.
- Add real project images and detailed pages.
- Hook the contact form to an email or server endpoint.
