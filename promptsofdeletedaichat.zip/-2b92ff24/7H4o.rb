require "jekyll-bookshop"
